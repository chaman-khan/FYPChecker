export const theme = {
    colors: {
      primary: '#1CB5FD',
      grey: '#9B9B9B',
    },
  };
  